//Breakout
var config = {
	type: Phaser.AUTO,
	width: 1024,
	height: 768,
physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 0},
            debug: false
        }
    },
scene: {
		init: init,
		preload: preload,
		create: create,
		update: update
	}
};

var game = new Phaser.Game(config);

function init(){
	var paddle;
	var cursors;
	var balle;
	var brique;
}

    function preload()
    {
        this.load.image('background','assets/breakoutBG.png');
        this.load.image('paddle','assets/paddle.png');
        this.load.image('balle', 'assets/ttc_balle.png');
        this.load.image('briqueV','assets/briqueV.png');
        this.load.image('briqueJ','assets/briqueJ.png');
        this.load.image('briqueR','assets/briqueR.png');
        this.load.image('briqueB','assets/briqueB.png');
    }

    function create()
    {

    this.physics.world.setBoundsCollision(true, true, true, false);


    brique = this.physics.add.staticGroup({  
        frameQuantity: 10
        gridAlign: { width: 10, height: 6, cellWidth: 64, cellHeight: 32, x: 112, y: 100 }
        });

    balle = this.physics.add.image(400, 500, 'assets', 'balle').setCollideWorldBounds(true).setBounce(1);
    this.balle.setData('onPaddle', true);

    paddle = this.physics.add.image(400, 550, 'assets', 'paddle');


    this.physics.add.collider(balle, brique, hitBrick, null, this);
    this.physics.add.collider(balle, paddle, hitPaddle, null, this);

    this.input.on('pointermove', function (pointer) {

    paddle.x = Phaser.Math.Clamp(pointer.x, 52, 748);

    if (balle.getData('onPaddle')){
        balle.x = paddle.x;
        }}, this);

    this.input.on('pointerup', function (pointer) {

            if (this.balle.getData('onPaddle'))
            {
                this.balle.setVelocity(-75, -300);
                this.balle.setData('onPaddle', false);
            }

        }, this);
    }

    function hitBrick (balle, brique)
    {
        brique.disableBody(true, true);

        if (this.brique.countActive() === 0)
        {
            this.resetLevel();
        }
    }

    function resetBall()
    {
        balle.setVelocity(0);
        balle.setPosition(this.paddle.x, 500);
        balle.setData('onPaddle', true);
    }

    function resetLevel ()
    {
        this.resetBall();

        this.brique.children.each(function (brique) {

            brique.enableBody(false, 0, 0, true, true);

        });
    }

    function hitPaddle(balle, paddle)
    {
        var diff = 0;

        if (balle.x < paddle.x){

            diff = paddle.x - balle.x;
            balle.setVelocityX(-10 * diff);
        }
        else if (balle.x > paddle.x){

            diff = balle.x -paddle.x;
            balle.setVelocityX(10 * diff);
        }
        else{

            balle.setVelocityX(2 + Math.random() * 8);
        }
    }

    function update (){
        if (this.balle.y > 600){
            this.resetBall();
        }
    }
