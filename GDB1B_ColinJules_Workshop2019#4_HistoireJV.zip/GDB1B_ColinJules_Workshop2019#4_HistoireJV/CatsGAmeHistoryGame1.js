//Tennis For Two
var config = {
	type: Phaser.AUTO,
	width: 1024,
	height: 768,
physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 0},
            debug: false
        }
    },
scene: {
		init: init,
		preload: preload,
		create: create,
		update: update
	}
};

var game = new Phaser.Game(config);

function init(){
 	var platforms;
	var player;
	var pc;
	var cursors;
	var scoreText;
	var balle;
	var velocityX=Phaser.Math.Between(-100, 100);
	var velocityY=100;
	var scorePlayer = 0;
	var scorePc = 0;
}

function preload(){
	this.load.image('background','assets/TTC_BG.png');
	this.load.image('balle','assets/ttc_balle.png');
	this.load.image('taby','assets/ttc_player1.png',{frameWidth: 150, frameHeight: 150});
	this.load.image('ginger','assets/ttc_player2.png',{frameWidth: 150, frameHeight: 150});
	this.load.image('platforms','assets/ttc_plats.png')
}



function create(){
	this.add.image(512, 384,'background');

	platforms = this.physics.add.staticGroup();
	platforms.create(512,28,'platforms').refreshBody().setAlpha(0);
	platforms.create(512,748,'platforms').refreshBody().setAlpha(0);
	
//creation du joueur

	player = this.physics.add.sprite(100,384,'taby');
	player.setCollideWorldBounds(true);
	player.setScale(1);
	player.body.setGravityY(000);
	this.physics.add.collider(player,platforms);

	cursors = this.input.keyboard.createCursorKeys(); 	

//ajout  de nouvelles touches pour le controle de l'autre chat

	console.log(cursors);
    this.keyW=this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.W);
    this.keyS=this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.S);

// creation du deuxieme personnage

	pc = this.physics.add.sprite(924,384,'ginger');
	pc.setCollideWorldBounds(true);
	pc.setBounce(0.2);
	pc.setScale(1);
	pc.setFlipX(true);
	pc.body.setGravityY(000);
	this.physics.add.collider(pc,platforms);

// préparation de la balle

	balle = this.physics.add.sprite(400, 200, 'balle');
    balle.setCollideWorldBounds(true);
    balle.setBounce(1);
    balle.setScale(0.75);
    balle.setVelocityY(velocityY);
    balle.setVelocityX(velocityX);

	this.physics.add.collider(balle, player, platforms, hitplayer, null, this);
	this.physics.add.collider(balle, pc, platforms, hitpc, null, this);

	scoreTextPc = this.add.text(16, 16, 'score: 0', { fontSize: '16px', fill: '#F00' });
    scoreTextPlayer = this.add.text(700, 16, 'score: 0', { fontSize: '16px', fill: '#00F' });
}

function update(){

if(cursors.up.isDown){
    player.setVelocityY(-150);
  }

  else if(cursors.down.isDown){
    player.setVelocityY(150);
  }

  else{
    player.setVelocityY(0);
  }

  if(this.keyW.isDown){
    pc.setVelocityY(-150);
  }

  else if(this.keyS.isDown){
    pc.setVelocityY(150);
  }

  else{
    pc.setVelocityY(0);
  }

//conditions de marquage de points

   if(balle.x==1020){
    scorePc += 1;
    scoreTextPc.setText('Score: ' + scorePc);
    reset();
  }

  if(balle.x==4){
    scorePlayer += 1;
    scoreTextPlayer.setText('Score: ' + scorePlayer);
    reset();    
  }

}

function hitPlayer(balle,player){
  velocityX=velocityX+50;
  velocityX=velocityX*-1;
  console.log(velocityX);
  
  balle.setVelocityX(velocityX);

  if(velocityY<0){
    velocityY=velocityY*-1
    balle.setVelocityY(velocityY);
  }
  player.setVelocityX(-1);
}

function hitPc(balle,pc){
  velocityX=velocityX-50;
  velocityX=velocityX*-1;
  console.log(velocityX);
  balle.setVelocityX(velocityX);

  if(velocityY<0){
    velocityY=velocityY*-1
    balle.setVelocityY(velocityY);
  }
  pc.setVelocityX(1);
}

function endGame(){
if(scorePlayer=5){
	scoreTextPlayer = this.add.text(700, 16, 'vous avez gagner!', { fontSize: '30px', fill: '#ff0000' });
}

}